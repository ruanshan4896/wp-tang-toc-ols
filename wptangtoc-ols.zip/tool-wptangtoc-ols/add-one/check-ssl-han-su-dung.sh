#!/bin/bash
# shellcheck disable=SC1091

# Số ngày trước khi hết hạn để cảnh báo
THRESHOLD=7

# --- Cấu hình ---
DOMAINS=()

for filepath in /etc/wptt/vhost/.*.conf; do
  [[ ! -f "$filepath" || "$filepath" == *"/..conf" ]] && continue

  domain="${filepath##*/}"
  domain="${domain%.conf}"
  domain="${domain#.}"

  if [[ "$domain" == ?*.?* ]]; then
    DOMAINS+=("$domain")
  fi
done

. /etc/wptt/.wptt.conf 2>/dev/null
. /etc/wptt/core-functions 2>/dev/null

telegram_tmp_api=$(wptt_giai_ma "$telegram_api" 2>/dev/null)
telegram_api="${telegram_tmp_api:-$telegram_api}"
telegram_tmp_id=$(wptt_giai_ma "$telegram_id" 2>/dev/null)
telegram_id="${telegram_tmp_id:-$telegram_id}"

# Telegram Bot API Token (LẤY TỪ BOTFATHER)
BOT_TOKEN="$telegram_api"

# Chat ID của người nhận/nhóm nhận tin nhắn (LẤY BẰNG CÁCH GỬI TIN NHẮN CHO BOT)
CHAT_ID="$telegram_id"

# Đường dẫn đến file log (tùy chọn)
# LOG_FILE="/var/log/ssl_expiry.log"

send_telegram_message() {
  local message="$1"
  local url_tele_goc="https://api.telegram.org/bot${BOT_TOKEN}/sendMessage"

  # LẦN 1: Thử gửi bằng API gốc
  local response
  response=$(curl -s -m 5 -X POST "$url_tele_goc" \
    -d chat_id="$CHAT_ID" \
    -d text="$message" \
    -d disable_web_page_preview="true" \
    -d parse_mode="markdown")

  # SIÊU KIỂM TRA TẦNG API: Nếu Telegram không trả về chữ "ok":true
  if [[ "$response" != *"\"ok\":true"* ]]; then

    # === BẬT CHẾ ĐỘ DỰ PHÒNG: CHUYỂN QUA PROXY ===
    local API_PROXY
    API_PROXY=$(curl --tlsv1.3 -sL -m 10 -H "User-Agent: wptangtoc ols get telegram" "https://hub.wptangtoc.com/get-telegram-work" | tr -d '\r\n[:space:]')

    local url_tele_proxy
    if [[ "$API_PROXY" == *"workers.dev"* ]]; then
      url_tele_proxy="https://$API_PROXY/bot${BOT_TOKEN}/sendMessage"
    fi

    # LẦN 2: Bắn lại qua Proxy
    curl -s -m 10 -X POST "$url_tele_proxy" \
      -d chat_id="$CHAT_ID" \
      -d text="$message" \
      -d disable_web_page_preview="true" \
      -d parse_mode="markdown" >/dev/null
  fi
}

# Hàm kiểm tra chứng chỉ
check_certificate() {
  local domain="$1"

  # Vá lỗi SC2155: Khai báo biến riêng, gán giá trị riêng
  local expiry_date
  #timeout 10 thêm cho chắc tránh bị kẹt tiến trình vĩnh viễn
  expiry_date=$(echo | timeout 10 openssl s_client -servername "$domain" -connect "$domain":443 2>/dev/null | openssl x509 -noout -enddate | cut -d= -f2-)

  # Kiểm tra xem openssl có trả về ngày hợp lệ không
  if [[ -z "$expiry_date" ]]; then
    return 1 # Trả về lỗi
  fi

  # Chuyển đổi ngày hết hạn sang timestamp
  expiry_timestamp=$(date -d "$expiry_date" +%s)
  current_timestamp=$(date +%s)
  days_remaining=$(((expiry_timestamp - current_timestamp) / 86400))

  if [[ $days_remaining -le $THRESHOLD ]]; then
    # Format message cho đẹp hơn với Markdown
    message="Cảnh báo chứng chỉ SSL $domain Hết hạn sau: $days_remaining ngày $expiry_date Vui lòng gia hạn sớm"
    send_telegram_message "$message"
  fi
}

# Vòng lặp qua các domain
for domain in "${DOMAINS[@]}"; do
  check_certificate "$domain"
done
